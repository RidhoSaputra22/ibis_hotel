<!DOCTYPE html>
<html lang="{{ str_replace('_', '-', app()->getLocale()) }}">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <title>{{ config('app.name', 'Laravel') }}</title>

    @vite(['resources/css/app.css', 'resources/js/app.js'])

    @stack('style')

    <script>
        tailwind.config = {
            theme: {
                extend: {
                    boxShadow: {
                        tile: '0 13px 28px rgba(0, 0, 0, .22)',
                    }
                }
            }
        }
    </script>

    <script src="https://unpkg.com/lucide@latest"></script>

</head>

<body class="">
    {{ $slot }}

    @stack('scripts')
</body>

</html>
