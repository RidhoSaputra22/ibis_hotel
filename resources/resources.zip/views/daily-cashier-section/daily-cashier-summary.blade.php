@php
    $outlets = [
        ['code' => '10', 'name' => 'Ibis Kitchen'],
        ['code' => '20', 'name' => 'Restaurant Terrace'],
        ['code' => '30', 'name' => 'Room Service'],
        ['code' => '40', 'name' => 'Banquet'],
        ['code' => '50', 'name' => 'Pool Bar'],
    ];

    $cashiers = [
        ['code' => 'ADHA', 'name' => 'Adha'],
        ['code' => 'FARHAN', 'name' => 'Farhan'],
        ['code' => 'NURUL', 'name' => 'Nurul'],
        ['code' => 'RIZKY', 'name' => 'Rizky'],
    ];
@endphp

<div class="min-h-screen bg-[linear-gradient(135deg,#dbe6e9_0%,#f7fbfc_53%,#d8e4e7_100%)]">
    {{-- Sidebar --}}
    <aside class="fixed inset-y-0 left-0 z-30 flex w-[58px] flex-col border-r border-[#2d659b] bg-[#0b4d8c] shadow-xl">
        <div class="flex h-[68px] items-center justify-center border-b border-white/20">
            <div class="grid h-9 w-9 place-items-center rounded-md border border-white/40 bg-white/15 text-xs font-black text-white">
                R
            </div>
        </div>

        <nav class="flex flex-1 flex-col items-center gap-1 py-3">
            @foreach ([
                ['Favorites', 'star'],
                ['Approval', 'circle-check'],
                ['Banquet', 'calendar-days'],
                ['Department Request', 'clipboard-list'],
                ['FB & Shop Cashier', 'shopping-bag', true],
                ['Sales', 'badge-dollar-sign'],
            ] as $menu)
                <button
                    type="button"
                    title="{{ $menu[0] }}"
                    class="flex h-[72px] w-full flex-col items-center justify-center gap-1 border-l-4 transition {{ !empty($menu[2]) ? 'border-white bg-white/15 text-white' : 'border-transparent text-blue-100 hover:bg-white/10 hover:text-white' }}"
                >
                    <i data-lucide="{{ $menu[1] }}" class="h-4 w-4"></i>
                    <span class="origin-center -rotate-90 whitespace-nowrap text-[9px] font-semibold tracking-wide">
                        {{ $menu[0] }}
                    </span>
                </button>
            @endforeach
        </nav>
    </aside>

    <main class="ml-[58px] min-h-screen">
        {{-- Header --}}
        <header class="flex h-[68px] items-center justify-between border-b border-slate-300 bg-[#081929] px-5 text-white shadow-md">
            <div class="flex items-center gap-3">
                <div class="grid h-9 w-9 place-items-center rounded-md bg-[#1b70b8] text-sm font-black shadow">R</div>
                <div>
                    <p class="text-xs font-semibold tracking-wide">Ibis Makassar City Center</p>
                    <p class="text-[10px] text-slate-400">Front Office &amp; Cashier System</p>
                </div>
            </div>

            <div class="flex items-center gap-3 text-slate-300">
                <button type="button" class="hover:text-white"><i data-lucide="search" class="h-4 w-4"></i></button>
                <button type="button" class="hover:text-white"><i data-lucide="bell" class="h-4 w-4"></i></button>
                <button type="button" class="hover:text-white"><i data-lucide="minus" class="h-4 w-4"></i></button>
                <button type="button" class="hover:text-white"><i data-lucide="square" class="h-3.5 w-3.5"></i></button>
                <button type="button" class="hover:text-rose-300"><i data-lucide="x" class="h-4 w-4"></i></button>
                <span class="hidden border-l border-white/10 pl-3 text-[10px] font-semibold text-slate-300 lg:inline">ADHA</span>
            </div>
        </header>

        {{-- Tab --}}
        <div class="border-b border-slate-300 bg-[#eaf1f3] px-5 py-2">
            <div class="flex flex-wrap items-center gap-1 text-[10px] font-medium">
                <a href="#" class="rounded-t border border-slate-300 bg-white px-3 py-1.5 text-slate-600 shadow-sm">Open Cashier</a>
                <span class="text-slate-400">›</span>
                <a href="{{ url('/restaurant-transaction') }}" class="rounded-t border border-slate-300 bg-white px-3 py-1.5 text-slate-600 shadow-sm">Restaurant Transaction</a>
                <span class="text-slate-400">›</span>
                <span class="rounded-t border border-b-white border-slate-300 bg-white px-3 py-1.5 font-bold text-[#1871ad] shadow-sm">Daily Cashier Summary</span>
            </div>
        </div>

        <section class="p-4 lg:p-5">
            <div class="min-h-[calc(100vh-125px)] overflow-hidden rounded-sm border border-slate-300 bg-[#f8fbfc] shadow-panel">
                <div class="border-b border-slate-200 bg-[#eff5f6] px-4 py-3">
                    <h1 class="text-sm font-bold text-[#536d76]">Daily Cashier Summary</h1>
                </div>

                <div class="grid min-h-[calc(100vh-179px)] grid-cols-1 lg:grid-cols-[550px_1fr]">
                    {{-- Filter kiri --}}
                    <aside class="border-b border-slate-200 bg-[#f3f8f9] p-5 lg:border-b-0 lg:border-r">
                        <div class="space-y-4">
                            <div class="grid grid-cols-[70px_1fr] items-center gap-3">
                                <label for="summaryDate" class="form-label">Date</label>
                                <input id="summaryDate" type="date" value="2026-06-15" class="form-control max-w-[170px]">
                            </div>

                            <div class="grid grid-cols-[70px_1fr] items-start gap-3">
                                <span class="form-label pt-1">Group by</span>
                                <div class="flex flex-wrap items-center gap-4">
                                    <label class="radio-label">
                                        <input type="radio" name="groupBy" value="outlet" checked>
                                        Outlet
                                    </label>
                                    <label class="radio-label">
                                        <input type="radio" name="groupBy" value="cashier">
                                        Cashier
                                    </label>
                                    <label class="radio-label">
                                        <input id="salesOnly" type="checkbox">
                                        Sales Only
                                    </label>
                                </div>
                            </div>
                        </div>

                        <fieldset id="outletFieldset" class="fieldset-panel mt-5">
                            <legend>Outlet</legend>
                            <div class="grid grid-cols-[50px_1fr] items-center gap-x-3 gap-y-3">
                                <label class="form-label">From</label>
                                <div class="grid grid-cols-[70px_1fr] gap-1.5">
                                    <select id="outletFrom" class="form-control">
                                        @foreach ($outlets as $outlet)
                                            <option value="{{ $outlet['code'] }}" @selected($outlet['code'] === '10')>{{ $outlet['code'] }}</option>
                                        @endforeach
                                    </select>
                                    <input id="outletFromName" value="Ibis Kitchen" readonly class="form-control bg-[#dfe8eb]">
                                </div>

                                <label class="form-label">To</label>
                                <div class="grid grid-cols-[70px_1fr] gap-1.5">
                                    <select id="outletTo" class="form-control">
                                        @foreach ($outlets as $outlet)
                                            <option value="{{ $outlet['code'] }}" @selected($outlet['code'] === '50')>{{ $outlet['code'] }}</option>
                                        @endforeach
                                    </select>
                                    <input id="outletToName" value="Pool Bar" readonly class="form-control bg-[#dfe8eb]">
                                </div>
                            </div>
                        </fieldset>

                        <fieldset id="cashierFieldset" class="fieldset-panel mt-4 opacity-60">
                            <legend>Cashier</legend>
                            <div class="grid grid-cols-[50px_1fr] items-center gap-x-3 gap-y-3">
                                <label class="form-label">From</label>
                                <div class="grid grid-cols-[110px_1fr] gap-1.5">
                                    <select id="cashierFrom" disabled class="form-control">
                                        @foreach ($cashiers as $cashier)
                                            <option value="{{ $cashier['code'] }}" @selected($cashier['code'] === 'ADHA')>{{ $cashier['code'] }}</option>
                                        @endforeach
                                    </select>
                                    <input id="cashierFromName" value="Adha" readonly class="form-control bg-[#dfe8eb]">
                                </div>

                                <label class="form-label">To</label>
                                <div class="grid grid-cols-[110px_1fr] gap-1.5">
                                    <select id="cashierTo" disabled class="form-control">
                                        @foreach ($cashiers as $cashier)
                                            <option value="{{ $cashier['code'] }}" @selected($cashier['code'] === 'RIZKY')>{{ $cashier['code'] }}</option>
                                        @endforeach
                                    </select>
                                    <input id="cashierToName" value="Rizky" readonly class="form-control bg-[#dfe8eb]">
                                </div>
                            </div>
                        </fieldset>

                        <fieldset class="fieldset-panel mt-4">
                            <legend>Output To</legend>
                            <div class="flex flex-wrap items-center gap-3">
                                <label class="radio-label">
                                    <input type="radio" name="outputTo" value="screen" checked>
                                    Screen
                                </label>
                                <label class="radio-label">
                                    <input type="radio" name="outputTo" value="printer">
                                    Printer
                                </label>
                                <input id="printerName" type="text" value="EPSON TM-U220 Slip" disabled class="form-control h-8 max-w-[190px] bg-[#dfe8eb] text-[10px]">
                                <button id="printerPropertiesButton" type="button" disabled class="small-button disabled:cursor-not-allowed disabled:opacity-50">Properties</button>
                            </div>
                        </fieldset>

                        <div class="mt-5 flex justify-end">
                            <button id="printSummaryButton" type="button" class="flex h-[68px] w-[105px] flex-col items-center justify-center gap-1 rounded-sm border border-[#79aebf] bg-[#d8edf3] text-[11px] font-bold text-[#3e6c7c] shadow-control transition hover:border-[#4e99b5] hover:bg-[#c7e6ef]">
                                <i data-lucide="printer" class="h-5 w-5"></i>
                                Print
                            </button>
                        </div>
                    </aside>

                    {{-- Output kanan --}}
                    <section class="relative min-h-[500px] bg-white">
                        <div id="emptyReportState" class="absolute inset-0 grid place-items-center p-8">
                            <div class="max-w-sm text-center">
                                <div class="mx-auto grid h-14 w-14 place-items-center rounded-full border border-[#d6e4e7] bg-[#f3f8f9] text-[#6c8993]">
                                    <i data-lucide="file-chart-column" class="h-6 w-6"></i>
                                </div>
                                <h2 class="mt-4 text-sm font-bold text-[#6d838b]">Daily Cashier Summary</h2>
                                <p class="mt-2 text-xs leading-relaxed text-[#87989d]">Atur parameter laporan pada panel kiri, lalu tekan tombol Print untuk menampilkan ringkasan transaksi harian.</p>
                            </div>
                        </div>

                        <div id="reportContainer" class="hidden p-6">
                            <div class="mx-auto max-w-4xl">
                                <div class="flex flex-wrap items-start justify-between gap-4 border-b border-slate-200 pb-5">
                                    <div>
                                        <p class="text-xs font-bold tracking-wide text-[#315f72]">IBIS MAKASSAR CITY CENTER</p>
                                        <h2 class="mt-1 text-lg font-black text-[#435f69]">Daily Cashier Summary</h2>
                                        <p id="reportMeta" class="mt-1 text-[11px] text-[#71868d]"></p>
                                    </div>
                                    <button id="browserPrintButton" type="button" class="small-button">
                                        <i data-lucide="printer" class="h-3.5 w-3.5"></i>
                                        Browser Print
                                    </button>
                                </div>

                                <div class="mt-5 grid grid-cols-1 gap-3 sm:grid-cols-3">
                                    <div class="report-stat"><span>Total Group</span><strong id="reportCashierCount">0</strong></div>
                                    <div class="report-stat"><span>Total Transaction</span><strong id="reportTransactionCount">0</strong></div>
                                    <div class="report-stat"><span>Total Sales</span><strong id="reportTotalSales">Rp0</strong></div>
                                </div>

                                <div class="mt-5 overflow-x-auto rounded-sm border border-[#b9cbd1]">
                                    <table class="min-w-[680px] w-full border-collapse text-left text-[11px]">
                                        <thead class="bg-[#dcecf0] text-[#536d76]">
                                            <tr class="border-b border-[#b7cbd1]">
                                                <th class="border-r border-[#c7d7db] px-3 py-2 font-bold">Group</th>
                                                <th class="border-r border-[#c7d7db] px-3 py-2 text-right font-bold">Cash Sales</th>
                                                <th class="border-r border-[#c7d7db] px-3 py-2 text-right font-bold">Card Sales</th>
                                                <th class="border-r border-[#c7d7db] px-3 py-2 text-right font-bold">Other Sales</th>
                                                <th class="border-r border-[#c7d7db] px-3 py-2 text-right font-bold">Transaction</th>
                                                <th class="px-3 py-2 text-right font-bold">Total</th>
                                            </tr>
                                        </thead>
                                        <tbody id="reportRows" class="text-[#5f747b]"></tbody>
                                        <tfoot id="reportFooter" class="border-t border-[#aebfc5] bg-[#f0f6f7] font-bold text-[#456772]"></tfoot>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </section>
                </div>
            </div>
        </section>
    </main>
</div>

{{-- Printer Properties --}}
<dialog id="printerPropertiesModal" class="m-auto w-[calc(100%-2rem)] max-w-md overflow-hidden rounded-sm border border-[#8fa6ae] bg-[#edf4f6] p-0 shadow-2xl backdrop:bg-slate-900/40">
    <div class="border-b border-[#afc2c8] bg-[linear-gradient(180deg,#eaf5f8_0%,#d5e8ee_100%)] px-4 py-3">
        <h2 class="text-xs font-bold text-[#536b74]">Printer Properties</h2>
    </div>
    <div class="space-y-4 p-5">
        <div>
            <label class="form-label">Printer</label>
            <select class="form-control">
                <option>EPSON TM-U220 Slip</option>
                <option>EPSON TM-T82 Receipt</option>
                <option>Microsoft Print to PDF</option>
            </select>
        </div>
        <div class="grid grid-cols-2 gap-3">
            <div>
                <label class="form-label">Paper Size</label>
                <select class="form-control"><option>Slip</option><option>A4</option></select>
            </div>
            <div>
                <label class="form-label">Copies</label>
                <input type="number" min="1" value="1" class="form-control">
            </div>
        </div>
    </div>
    <div class="flex justify-end gap-2 border-t border-[#c5d4d8] bg-[#edf4f6] px-4 py-3">
        <button type="button" id="closePrinterProperties" class="small-button">Cancel</button>
        <button type="button" id="savePrinterProperties" class="small-button !border-[#79aebf] !bg-[#d8edf3] !text-[#3e6c7c]">Save</button>
    </div>
</dialog>

<style>
    .form-label { display:block; font-size:10px; font-weight:700; text-transform:uppercase; color:#667e86; }
    .form-control { height:32px; width:100%; border-radius:2px; border:1px solid #bdcdd2; background:#fff; padding:0 .55rem; font-size:11px; color:#536d76; outline:none; box-shadow:inset 0 1px 1px rgba(15,23,42,.04); }
    .form-control:focus { border-color:#61a8c3; box-shadow:0 0 0 3px rgba(56,189,248,.15); }
    .fieldset-panel { border:1px solid #bfd0d5; border-radius:2px; background:#f9fcfd; padding:1rem; }
    .fieldset-panel legend { padding:0 .25rem; font-size:11px; font-weight:700; color:#607780; }
    .radio-label { display:inline-flex; cursor:pointer; align-items:center; gap:.35rem; font-size:11px; font-weight:600; color:#5b7179; }
    .radio-label input { height:.875rem; width:.875rem; border-color:#cbd5e1; color:#2d93bb; }
    .small-button { display:inline-flex; min-height:32px; align-items:center; justify-content:center; gap:.4rem; border-radius:2px; border:1px solid #b4c6cb; background:#fff; padding:.4rem .7rem; font-size:10px; font-weight:700; color:#5f767e; box-shadow:inset 0 1px 0 rgba(255,255,255,.95); transition:.15s ease; }
    .small-button:hover { border-color:#6ba9c0; background:#e6f4f7; color:#236984; }
    .report-stat { border:1px solid #c8d8dc; border-radius:2px; background:#f4f9fa; padding:.85rem 1rem; }
    .report-stat span { display:block; font-size:10px; font-weight:700; text-transform:uppercase; color:#7a9097; }
    .report-stat strong { display:block; margin-top:.35rem; font-size:16px; color:#3b6677; }
    @media print {
        body * { visibility:hidden; }
        #reportContainer, #reportContainer * { visibility:visible; }
        #reportContainer { position:fixed; inset:0; display:block!important; width:100%; background:white; }
        #browserPrintButton { display:none; }
    }
</style>

<script>
    lucide.createIcons({ attrs: { 'stroke-width': 1.8 } });

    const outletData = @json($outlets);
    const cashierData = @json($cashiers);

    const summaryDate = document.getElementById('summaryDate');
    const groupByInputs = [...document.querySelectorAll('input[name="groupBy"]')];
    const salesOnly = document.getElementById('salesOnly');
    const outletFieldset = document.getElementById('outletFieldset');
    const cashierFieldset = document.getElementById('cashierFieldset');

    const outletFrom = document.getElementById('outletFrom');
    const outletTo = document.getElementById('outletTo');
    const outletFromName = document.getElementById('outletFromName');
    const outletToName = document.getElementById('outletToName');

    const cashierFrom = document.getElementById('cashierFrom');
    const cashierTo = document.getElementById('cashierTo');
    const cashierFromName = document.getElementById('cashierFromName');
    const cashierToName = document.getElementById('cashierToName');

    const outputInputs = [...document.querySelectorAll('input[name="outputTo"]')];
    const printerName = document.getElementById('printerName');
    const printerPropertiesButton = document.getElementById('printerPropertiesButton');
    const printerPropertiesModal = document.getElementById('printerPropertiesModal');

    const printSummaryButton = document.getElementById('printSummaryButton');
    const emptyReportState = document.getElementById('emptyReportState');
    const reportContainer = document.getElementById('reportContainer');
    const reportRows = document.getElementById('reportRows');
    const reportFooter = document.getElementById('reportFooter');

    function rupiah(value) {
        return new Intl.NumberFormat('id-ID', { style:'currency', currency:'IDR', maximumFractionDigits:0 }).format(value);
    }

    function findName(data, code) {
        return data.find((item) => item.code === code)?.name ?? '-';
    }

    function updateOutletNames() {
        outletFromName.value = findName(outletData, outletFrom.value);
        outletToName.value = findName(outletData, outletTo.value);
    }

    function updateCashierNames() {
        cashierFromName.value = findName(cashierData, cashierFrom.value);
        cashierToName.value = findName(cashierData, cashierTo.value);
    }

    function selectedGroupBy() {
        return groupByInputs.find((input) => input.checked)?.value || 'outlet';
    }

    function updateGroupByUI() {
        const isOutlet = selectedGroupBy() === 'outlet';
        outletFieldset.classList.toggle('opacity-60', !isOutlet);
        cashierFieldset.classList.toggle('opacity-60', isOutlet);
        outletFrom.disabled = !isOutlet;
        outletTo.disabled = !isOutlet;
        cashierFrom.disabled = isOutlet;
        cashierTo.disabled = isOutlet;
    }

    function updateOutputUI() {
        const isPrinter = outputInputs.find((input) => input.checked)?.value === 'printer';
        printerName.disabled = !isPrinter;
        printerPropertiesButton.disabled = !isPrinter;
    }

    function sourceRows() {
        const factor = salesOnly.checked ? 0.78 : 1;

        const rows = selectedGroupBy() === 'outlet'
            ? [
                { group:'Ibis Kitchen', cash:1285000, card:980000, other:127000, transaction:81 },
                { group:'Restaurant Terrace', cash:710000, card:465000, other:52000, transaction:47 },
                { group:'Room Service', cash:430000, card:295000, other:32000, transaction:31 },
                { group:'Banquet', cash:935000, card:750000, other:88000, transaction:26 },
                { group:'Pool Bar', cash:285000, card:210000, other:24000, transaction:19 },
            ]
            : [
                { group:'ADHA', cash:1180000, card:935000, other:104000, transaction:72 },
                { group:'FARHAN', cash:895000, card:735000, other:71000, transaction:55 },
                { group:'NURUL', cash:860000, card:650000, other:82000, transaction:47 },
                { group:'RIZKY', cash:710000, card:380000, other:66000, transaction:30 },
            ];

        return rows.map((row) => ({
            ...row,
            cash:Math.round(row.cash * factor),
            card:Math.round(row.card * factor),
            other:Math.round(row.other * factor),
            transaction:Math.round(row.transaction * factor),
        }));
    }

    function renderReport() {
        const rows = sourceRows();
        const groupBy = selectedGroupBy();
        const dateText = new Intl.DateTimeFormat('id-ID', { day:'2-digit', month:'long', year:'numeric' }).format(new Date(`${summaryDate.value}T00:00:00`));

        const totalCash = rows.reduce((sum,row) => sum + row.cash, 0);
        const totalCard = rows.reduce((sum,row) => sum + row.card, 0);
        const totalOther = rows.reduce((sum,row) => sum + row.other, 0);
        const totalTransaction = rows.reduce((sum,row) => sum + row.transaction, 0);
        const totalSales = totalCash + totalCard + totalOther;

        document.getElementById('reportMeta').textContent =
            `Date: ${dateText} · Group By: ${groupBy === 'outlet' ? 'Outlet' : 'Cashier'}${salesOnly.checked ? ' · Sales Only' : ''}`;

        document.getElementById('reportCashierCount').textContent = rows.length;
        document.getElementById('reportTransactionCount').textContent = totalTransaction;
        document.getElementById('reportTotalSales').textContent = rupiah(totalSales);

        reportRows.innerHTML = rows.map((row) => {
            const total = row.cash + row.card + row.other;
            return `
                <tr class="border-b border-[#d7e3e6] hover:bg-[#f6fbfc]">
                    <td class="border-r border-[#e0e9eb] px-3 py-2 font-semibold">${row.group}</td>
                    <td class="border-r border-[#e0e9eb] px-3 py-2 text-right">${rupiah(row.cash)}</td>
                    <td class="border-r border-[#e0e9eb] px-3 py-2 text-right">${rupiah(row.card)}</td>
                    <td class="border-r border-[#e0e9eb] px-3 py-2 text-right">${rupiah(row.other)}</td>
                    <td class="border-r border-[#e0e9eb] px-3 py-2 text-right">${row.transaction}</td>
                    <td class="px-3 py-2 text-right font-bold text-[#3c6b7b]">${rupiah(total)}</td>
                </tr>
            `;
        }).join('');

        reportFooter.innerHTML = `
            <tr>
                <td class="border-r border-[#c7d7db] px-3 py-2">TOTAL</td>
                <td class="border-r border-[#c7d7db] px-3 py-2 text-right">${rupiah(totalCash)}</td>
                <td class="border-r border-[#c7d7db] px-3 py-2 text-right">${rupiah(totalCard)}</td>
                <td class="border-r border-[#c7d7db] px-3 py-2 text-right">${rupiah(totalOther)}</td>
                <td class="border-r border-[#c7d7db] px-3 py-2 text-right">${totalTransaction}</td>
                <td class="px-3 py-2 text-right">${rupiah(totalSales)}</td>
            </tr>
        `;

        emptyReportState.classList.add('hidden');
        reportContainer.classList.remove('hidden');

        if (outputInputs.find((input) => input.checked)?.value === 'printer') {
            setTimeout(() => window.print(), 250);
        }
    }

    groupByInputs.forEach((input) => input.addEventListener('change', updateGroupByUI));
    outputInputs.forEach((input) => input.addEventListener('change', updateOutputUI));
    outletFrom.addEventListener('change', updateOutletNames);
    outletTo.addEventListener('change', updateOutletNames);
    cashierFrom.addEventListener('change', updateCashierNames);
    cashierTo.addEventListener('change', updateCashierNames);
    printSummaryButton.addEventListener('click', renderReport);
    document.getElementById('browserPrintButton').addEventListener('click', () => window.print());

    printerPropertiesButton.addEventListener('click', () => printerPropertiesModal.showModal());
    document.getElementById('closePrinterProperties').addEventListener('click', () => printerPropertiesModal.close());
    document.getElementById('savePrinterProperties').addEventListener('click', () => printerPropertiesModal.close());
    printerPropertiesModal.addEventListener('click', (event) => {
        if (event.target === printerPropertiesModal) printerPropertiesModal.close();
    });

    updateOutletNames();
    updateCashierNames();
    updateGroupByUI();
    updateOutputUI();
</script>
