@php
    $tables = collect(range(1, 20))->map(fn($number) => str_pad($number, 2, '0', STR_PAD_LEFT));
@endphp

<div class="min-h-screen bg-[linear-gradient(135deg,#dce7ea_0%,#f8fbfc_55%,#dce8ec_100%)]">
    {{-- Sidebar seperti aplikasi kasir sebelumnya --}}
    <aside class="fixed inset-y-0 left-0 z-30 flex w-[58px] flex-col border-r border-[#2e6499] bg-[#0b4d8c] shadow-xl">
        <div class="flex h-[68px] items-center justify-center border-b border-white/20">
            <div
                class="grid h-9 w-9 place-items-center rounded-md border border-white/40 bg-white/15 text-xs font-black text-white">
                R
            </div>
        </div>

        <nav class="flex flex-1 flex-col items-center gap-1 py-3">
            @foreach ([['Favorites', 'star'], ['Approval', 'circle-check'], ['Input', 'keyboard'], ['Request', 'clipboard-list'], ['Department Report', 'chart-no-axes-combined'], ['FB & Shop Cashier', 'shopping-bag', true], ['Sales', 'badge-dollar-sign']] as $menu)
                <button type="button" title="{{ $menu[0] }}"
                    class="group relative flex h-[72px] w-full flex-col items-center justify-center gap-1 border-l-4 transition {{ !empty($menu[2]) ? 'border-white bg-white/15 text-white' : 'border-transparent text-blue-100 hover:bg-white/10 hover:text-white' }}">
                    <i data-lucide="{{ $menu[1] }}" class="h-4 w-4"></i>
                    <span class="origin-center -rotate-90 whitespace-nowrap text-[9px] font-semibold tracking-wide">
                        {{ $menu[0] }}
                    </span>
                </button>
            @endforeach
        </nav>
    </aside>

    <main class="ml-[58px] min-h-screen">
        {{-- Top header --}}
        <header
            class="flex h-[68px] items-center justify-between border-b border-slate-300 bg-[#0a1a2a] px-5 text-white shadow-md">
            <div class="flex items-center gap-3">
                <div class="grid h-9 w-9 place-items-center rounded-md bg-[#1b70b8] text-sm font-black shadow">
                    R
                </div>

                <div>
                    <p class="text-xs font-semibold tracking-wide">Ibis Makassar City Center</p>
                    <p class="text-[10px] text-slate-400">Restaurant &amp; Cashier System</p>
                </div>
            </div>

            <div class="flex items-center gap-3 text-slate-300">
                <button type="button" class="hover:text-white" title="Cari">
                    <i data-lucide="search" class="h-4 w-4"></i>
                </button>
                <button type="button" class="hover:text-white" title="Notifikasi">
                    <i data-lucide="bell" class="h-4 w-4"></i>
                </button>
                <button type="button" class="hover:text-red-300" title="Tutup">
                    <i data-lucide="x" class="h-4 w-4"></i>
                </button>
            </div>
        </header>

        {{-- Breadcrumb / Tab --}}
        <div class="border-b border-slate-300 bg-[#eaf1f3] px-5 py-2">
            <div class="flex flex-wrap items-center gap-1 text-[10px] font-medium">
                <a href="#"
                    class="rounded-t border border-slate-300 bg-white px-3 py-1.5 text-slate-600 shadow-sm">
                    Open Cashier
                </a>

                <span class="text-slate-400">›</span>

                <a href="#"
                    class="rounded-t border border-slate-300 bg-white px-3 py-1.5 text-slate-600 shadow-sm">
                    FB &amp; Shop Cashier
                </a>

                <span class="text-slate-400">›</span>

                <a href="#"
                    class="rounded-t border border-slate-300 bg-white px-3 py-1.5 text-slate-600 shadow-sm">
                    Restaurant Transaction
                </a>

                <span class="text-slate-400">›</span>

                <span
                    class="rounded-t border border-b-white border-slate-300 bg-white px-3 py-1.5 font-bold text-[#1871ad] shadow-sm">
                    TABLE LIST
                </span>
            </div>
        </div>

        <section class="p-4 lg:p-6">
            <div
                class="min-h-[calc(100vh-145px)] overflow-hidden rounded-sm border border-slate-300 bg-[#f8fbfc] shadow-sm">
                {{-- Top area --}}
                <div
                    class="relative flex min-h-14 items-center justify-center border-b border-slate-200 bg-white px-4 py-3">
                    <h1 class="text-sm font-bold tracking-wide text-slate-600">
                        TABLE LIST
                    </h1>

                    <div class="absolute right-4 top-1/2 hidden -translate-y-1/2 items-center gap-2 lg:flex">
                        <label for="tableFilter" class="text-[10px] text-slate-500">Filter by table:</label>
                        <select id="tableFilter"
                            class="h-7 w-36 rounded-sm border border-slate-300 bg-white px-2 text-[10px] text-slate-600 outline-none focus:border-sky-500 focus:ring-2 focus:ring-sky-100">
                            <option value="all">Semua Table</option>
                            <option value="available">Available</option>
                            <option value="occupied">Occupied</option>
                        </select>
                    </div>
                </div>

                <div class="grid min-h-[calc(100vh-203px)] grid-cols-1 lg:grid-cols-[200px_1fr]">
                    {{-- Panel kiri --}}
                    <aside class="border-b border-slate-200 bg-[#f2f7f8] p-4 lg:border-b-0 lg:border-r">
                        <label for="tableSearch" class="sr-only">Cari table</label>

                        <div class="relative">
                            <input id="tableSearch" type="search" placeholder="Cari nomor meja"
                                class="h-9 w-full rounded-sm border border-slate-300 bg-white pl-8 pr-3 text-xs text-slate-700 outline-none transition placeholder:text-slate-400 focus:border-sky-500 focus:ring-2 focus:ring-sky-100">
                            <i data-lucide="search"
                                class="pointer-events-none absolute left-2.5 top-1/2 h-3.5 w-3.5 -translate-y-1/2 text-slate-400"></i>
                        </div>

                        <button type="button" id="findTableButton"
                            class="mt-3 w-full rounded-sm border border-[#8db4c6] bg-[#e7f3f7] px-3 py-2 text-[10px] font-bold uppercase text-[#396a80] shadow-sm transition hover:bg-[#d5ebf2] active:translate-y-px">
                            Find Table
                        </button>

                        <div class="mt-6 border-t border-slate-200 pt-4">
                            <p class="text-[10px] font-semibold uppercase tracking-wide text-slate-500">Informasi</p>
                            <p id="selectedInfo" class="mt-2 text-xs text-slate-600">
                                Belum ada meja dipilih.
                            </p>
                        </div>
                    </aside>

                    {{-- Table list --}}
                    <section class="p-5 lg:p-7">
                        <div id="tableGrid" class="grid max-w-[360px] grid-cols-3 gap-1.5"
                            aria-label="Daftar meja restoran">
                            @foreach ($tables as $table)
                                @php
                                    $status = in_array((int) $table, [3, 7, 12, 18]) ? 'occupied' : 'available';
                                @endphp

                                <button type="button" data-table-number="{{ $table }}"
                                    data-table-status="{{ $status }}"
                                    class="table-card group flex h-14 items-center justify-center rounded-sm border border-[#abc0c9] bg-[#e7f2f5] text-sm font-bold text-[#497485] shadow-[inset_0_1px_0_rgba(255,255,255,.9)] transition duration-150 hover:-translate-y-0.5 hover:border-[#5497b8] hover:bg-[#d4ebf3] hover:text-[#175f82] focus:outline-none focus:ring-4 focus:ring-sky-100 {{ $table === '01' ? 'ring-2 ring-[#247ead] ring-offset-1' : '' }}">
                                    {{ $table }}
                                </button>
                            @endforeach
                        </div>

                        <p id="emptyMessage" class="hidden py-10 text-center text-sm text-slate-400">
                            Nomor meja tidak ditemukan.
                        </p>
                    </section>
                </div>
            </div>
        </section>
    </main>
</div>

@push('scripts')
    <script>
        lucide.createIcons({
            attrs: {
                'stroke-width': 1.8
            }
        });

        const searchInput = document.getElementById('tableSearch');
        const filterSelect = document.getElementById('tableFilter');
        const cards = [...document.querySelectorAll('.table-card')];
        const selectedInfo = document.getElementById('selectedInfo');
        const emptyMessage = document.getElementById('emptyMessage');
        const findTableButton = document.getElementById('findTableButton');

        function filterTables() {
            const keyword = searchInput.value.trim().toLowerCase();
            const selectedFilter = filterSelect.value;
            let visibleTotal = 0;

            cards.forEach((card) => {
                const number = card.dataset.tableNumber.toLowerCase();
                const status = card.dataset.tableStatus;

                const matchesText = number.includes(keyword);
                const matchesStatus = selectedFilter === 'all' || status === selectedFilter;
                const isVisible = matchesText && matchesStatus;

                card.classList.toggle('hidden', !isVisible);
                if (isVisible) visibleTotal++;
            });

            emptyMessage.classList.toggle('hidden', visibleTotal > 0);
        }

        searchInput.addEventListener('input', filterTables);
        filterSelect.addEventListener('change', filterTables);

        findTableButton.addEventListener('click', () => {
            searchInput.focus();
            filterTables();
        });

        cards.forEach((card) => {
            card.addEventListener('click', () => {
                cards.forEach((item) => {
                    item.classList.remove('ring-2', 'ring-[#247ead]', 'ring-offset-1');
                });

                card.classList.add('ring-2', 'ring-[#247ead]', 'ring-offset-1');

                const number = card.dataset.tableNumber;
                const status = card.dataset.tableStatus === 'available' ? 'Available' : 'Occupied';

                selectedInfo.innerHTML = `
                Meja <strong>${number}</strong> dipilih.<br>
                Status: <strong>${status}</strong>
            `;
            });
        });
    </script>
@endpush
