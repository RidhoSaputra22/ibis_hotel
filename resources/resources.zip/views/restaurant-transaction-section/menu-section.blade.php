@php
    $master = [
        ['label' => 'Service Category 1', 'icon' => 'footprints'],
        ['label' => 'Outlet Master', 'icon' => 'store'],
        ['label' => 'Service Category 2', 'icon' => 'bottle-wine'],
        ['label' => 'Service Table', 'icon' => 'table-properties'],
        ['label' => 'Outlet Type', 'icon' => 'panels-top-left'],
    ];

    $transaction = [
        ['label' => 'Open Cashier', 'icon' => 'wallet-cards'],
        ['label' => 'Retail Transaction', 'icon' => 'store'],
        ['label' => 'Service Request / From Guest', 'icon' => 'clipboard-list'],
        ['label' => 'Folio Fast Check', 'icon' => 'receipt-text'],
        ['label' => 'F&B Point Desk', 'icon' => 'users-round'],
        ['label' => 'Restaurant Transaction', 'icon' => 'utensils'],
        ['label' => 'Customer Relation & Management', 'icon' => 'monitor-smartphone'],
        ['label' => 'Non Revenue Folio Transaction', 'icon' => 'file-text'],
        ['label' => 'Facility Reservation', 'icon' => 'calendar-check-2'],
        ['label' => 'Folio Guest Record', 'icon' => 'notebook-pen'],
        ['label' => 'Folio Transaction', 'icon' => 'files'],
    ];

    $batch = [
        ['label' => 'Soft Close A/R Period', 'icon' => 'book-open-check'],
    ];

    $reports = [
        ['label' => 'Detail Cash Cashier', 'icon' => 'contact-round'],
        ['label' => 'Package Service Daily Forecast', 'icon' => 'user-round-check'],
        ['label' => 'Cash Out', 'icon' => 'banknote-arrow-down'],
        ['label' => 'Point Refund', 'icon' => 'hand-coins'],
        ['label' => 'Daily Cashier Summary', 'icon' => 'notebook-tabs'],
        ['label' => 'Credit Card Transaction', 'icon' => 'credit-card'],
        ['label' => 'Vip Guest List', 'icon' => 'clipboard-check'],
        ['label' => 'Print Outlet Bill', 'icon' => 'printer'],
        ['label' => 'Daily Outlet Report', 'icon' => 'store'],
        ['label' => 'Bill/Ref. Cashier', 'icon' => 'receipt'],
        ['label' => 'Debit Card Transaction', 'icon' => 'landmark'],
        ['label' => 'Guest In House', 'icon' => 'house'],
        ['label' => 'Unpaid Bill Report', 'icon' => 'file-warning'],
        ['label' => 'Daily Rebate Record', 'icon' => 'badge-percent'],
        ['label' => 'Daily Cashier Record', 'icon' => 'clipboard-list'],
        ['label' => 'Sales Analysis', 'icon' => 'chart-no-axes-combined'],
        ['label' => 'City Ledger Transfer', 'icon' => 'files'],
        ['label' => 'Service Price List', 'icon' => 'badge-dollar-sign'],
        ['label' => 'Taking Over Charges', 'icon' => 'clipboard-pen-line'],
        ['label' => 'Daily Cashier Record', 'icon' => 'badge-check'],
        ['label' => 'Outlet Payment', 'icon' => 'wallet'],
        ['label' => 'Sales Summary', 'icon' => 'bar-chart-3'],
    ];

    $sidebar = [
        ['label' => 'Favorites', 'icon' => 'star'],
        ['label' => 'Approval', 'icon' => 'circle-check'],
        ['label' => 'Input', 'icon' => 'keyboard'],
        ['label' => 'Receipt', 'icon' => 'receipt-text'],
        ['label' => 'Department Report', 'icon' => 'chart-column'],
        ['label' => 'FB & Shop Cashier', 'icon' => 'shopping-bag', 'active' => true],
        ['label' => 'Sales', 'icon' => 'badge-dollar-sign'],
    ];
@endphp

<div class="min-h-screen bg-[radial-gradient(circle_at_75%_3%,rgba(23,74,106,.25),transparent_28%),linear-gradient(120deg,#06111d_0%,#092036_45%,#06121f_100%)]">
    {{-- Left vertical menu --}}
    <aside class="fixed inset-y-0 left-0 z-30 flex w-[58px] flex-col border-r border-white/10 bg-[#0c4a86] shadow-2xl">
        <div class="flex h-[70px] items-center justify-center border-b border-white/20">
            <div class="grid h-9 w-9 place-items-center rounded-lg border border-white/40 bg-white/15 text-sm font-black text-white">
                R
            </div>
        </div>

        <nav class="flex flex-1 flex-col items-center gap-1 py-3">
            @foreach ($sidebar as $menu)
                <button
                    type="button"
                    title="{{ $menu['label'] }}"
                    class="group relative flex h-[72px] w-full flex-col items-center justify-center gap-1 border-l-4 transition {{ !empty($menu['active']) ? 'border-white bg-white/15 text-white' : 'border-transparent text-blue-100 hover:bg-white/10 hover:text-white' }}"
                >
                    <i data-lucide="{{ $menu['icon'] }}" class="h-4 w-4"></i>
                    <span class="origin-center -rotate-90 whitespace-nowrap text-[9px] font-semibold tracking-wide">
                        {{ $menu['label'] }}
                    </span>
                </button>
            @endforeach
        </nav>
    </aside>

    <main class="ml-[58px] min-h-screen">
        {{-- Top bar --}}
        <header class="flex min-h-[70px] items-center justify-between border-b border-white/10 bg-[#06111d]/80 px-5 py-3 backdrop-blur">
            <div class="flex items-center gap-3">
                <div class="grid h-9 w-9 place-items-center rounded-md bg-blue-600 shadow-lg">
                    <span class="text-lg font-black">R</span>
                </div>
                <div>
                    <p class="text-xs font-semibold uppercase tracking-[0.14em] text-blue-100">Ibis Makassar City Center</p>
                    <p class="text-[10px] text-slate-400">Front Office System</p>
                </div>
            </div>

            <div class="hidden items-center gap-2 sm:flex">
                <span class="grid h-8 w-8 place-items-center rounded-full bg-[#a85f5c] text-xs font-bold">F</span>
                <span class="grid h-8 w-8 place-items-center rounded-full bg-slate-500 text-xs font-bold">B</span>
                <span class="grid h-8 w-8 place-items-center rounded-full bg-[#85835c] text-xs font-bold">S</span>
            </div>

            <div class="flex items-center gap-3 text-slate-300">
                <button class="transition hover:text-white" title="Cari"><i data-lucide="search" class="h-4 w-4"></i></button>
                <button class="transition hover:text-white" title="Notifikasi"><i data-lucide="bell" class="h-4 w-4"></i></button>
                <button class="transition hover:text-white" title="Minimalkan"><i data-lucide="minus" class="h-4 w-4"></i></button>
                <button class="transition hover:text-white" title="Maksimalkan"><i data-lucide="square" class="h-3.5 w-3.5"></i></button>
                <button class="transition hover:text-red-300" title="Keluar"><i data-lucide="x" class="h-4 w-4"></i></button>
                <span class="hidden border-l border-white/10 pl-3 text-[10px] font-semibold text-slate-300 md:inline">ADHA</span>
            </div>
        </header>

        <section class="px-5 py-5 lg:px-7">
            <div class="mb-6 flex items-center gap-3">
                <button class="grid h-8 w-8 place-items-center rounded-full border border-white/30 text-white transition hover:bg-white/10" title="Kembali">
                    <i data-lucide="arrow-left" class="h-4 w-4"></i>
                </button>
                <div>
                    <h1 class="text-xl font-bold tracking-tight text-white">FB &amp; Shop Cashier</h1>
                    <p class="mt-0.5 text-xs text-slate-400">Kelola transaksi, outlet, kasir, dan laporan.</p>
                </div>
            </div>

            <div class="grid gap-6 xl:grid-cols-[180px_minmax(360px,1fr)_130px_minmax(430px,1.35fr)]">
                {{-- Master --}}
                <section>
                    <h2 class="mb-2 text-xs font-bold text-slate-300">Master</h2>
                    <div class="grid grid-cols-2 gap-1.5">
                        @foreach ($master as $item)
                            <button class="group flex min-h-[110px] flex-col items-center justify-center gap-3 bg-[#f5837d] px-2 text-center shadow-tile transition duration-200 hover:-translate-y-1 hover:brightness-110">
                                <i data-lucide="{{ $item['icon'] }}" class="h-10 w-10 stroke-[1.8] text-white"></i>
                                <span class="text-[10px] font-bold leading-tight text-white">{{ $item['label'] }}</span>
                            </button>
                        @endforeach
                    </div>
                </section>

                {{-- Transaction --}}
                <section>
                    <h2 class="mb-2 text-xs font-bold text-slate-300">Transaction</h2>
                    <div class="grid grid-cols-2 gap-1.5 sm:grid-cols-3 lg:grid-cols-4">
                        @foreach ($transaction as $item)
                            <button class="group flex min-h-[110px] flex-col items-center justify-center gap-3 bg-[#11a9ed] px-2 text-center shadow-tile transition duration-200 hover:-translate-y-1 hover:brightness-110">
                                <i data-lucide="{{ $item['icon'] }}" class="h-10 w-10 stroke-[1.8] text-white"></i>
                                <span class="text-[10px] font-bold leading-tight text-white">{{ $item['label'] }}</span>
                            </button>
                        @endforeach
                    </div>
                </section>

                {{-- Batch --}}
                <section>
                    <h2 class="mb-2 text-xs font-bold text-slate-300">Batch</h2>
                    <button class="group flex min-h-[110px] w-full flex-col items-center justify-center gap-3 bg-[#9f79b7] px-2 text-center shadow-tile transition duration-200 hover:-translate-y-1 hover:brightness-110">
                        <i data-lucide="{{ $batch[0]['icon'] }}" class="h-10 w-10 stroke-[1.8] text-white"></i>
                        <span class="text-[10px] font-bold leading-tight text-white">{{ $batch[0]['label'] }}</span>
                    </button>
                </section>

                {{-- Reports --}}
                <section>
                    <h2 class="mb-2 text-xs font-bold text-slate-300">Report</h2>
                    <div class="grid grid-cols-2 gap-1.5 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5">
                        @foreach ($reports as $item)
                            <button class="group flex min-h-[110px] flex-col items-center justify-center gap-3 bg-[#07913d] px-2 text-center shadow-tile transition duration-200 hover:-translate-y-1 hover:brightness-110">
                                <i data-lucide="{{ $item['icon'] }}" class="h-9 w-9 stroke-[1.8] text-white"></i>
                                <span class="text-[10px] font-bold leading-tight text-white">{{ $item['label'] }}</span>
                            </button>
                        @endforeach
                    </div>
                </section>
            </div>
        </section>

        <footer class="flex flex-wrap items-center justify-between gap-3 border-t border-white/10 px-5 py-3 text-[10px] text-slate-400 lg:px-7">
            <span>Cashier Dashboard · Tailwind UI</span>
            <span>{{ now()->format('H:i') }} · {{ now()->format('d/m/Y') }}</span>
        </footer>
    </main>
</div>

@push('scripts')
 

<script>
    lucide.createIcons({
        attrs: {
            'stroke-width': 1.8
        }
    });
</script>

@endpush
