@php
    $zones = range('A', 'J');

    $serviceCategories = [
        'Appetizer',
        'Buffet',
        'Dessert',
        'Vegetarian',
        'Food Promotion',
        'GRAB FOOD',
        'Nusantara Food',
    ];

    $serviceItems = [
        ['name' => 'Gado-Gado', 'price' => 35000, 'category' => 'Appetizer'],
        ['name' => 'Spring Roll', 'price' => 30000, 'category' => 'Appetizer'],
        ['name' => 'Chicken Satay', 'price' => 55000, 'category' => 'Appetizer'],
        ['name' => 'Nasi Goreng Special', 'price' => 65000, 'category' => 'Nusantara Food'],
        ['name' => 'Mie Goreng', 'price' => 60000, 'category' => 'Nusantara Food'],
        ['name' => 'Soto Ayam', 'price' => 45000, 'category' => 'Nusantara Food'],
        ['name' => 'Caesar Salad', 'price' => 50000, 'category' => 'Vegetarian'],
        ['name' => 'French Fries', 'price' => 28000, 'category' => 'Food Promotion'],
        ['name' => 'Chocolate Cake', 'price' => 40000, 'category' => 'Dessert'],
        ['name' => 'Ice Tea', 'price' => 18000, 'category' => 'Buffet'],
        ['name' => 'Mineral Water', 'price' => 12000, 'category' => 'Buffet'],
        ['name' => 'Coffee Latte', 'price' => 35000, 'category' => 'Buffet'],
    ];
@endphp

<div class="min-h-screen bg-[linear-gradient(135deg,#dbe6e9_0%,#f8fbfc_53%,#dae5e8_100%)]">
    {{-- Sidebar aplikasi --}}
    <aside class="fixed inset-y-0 left-0 z-30 flex w-[58px] flex-col border-r border-[#2f6499] bg-[#0b4d8c] shadow-xl">
        <div class="flex h-[68px] items-center justify-center border-b border-white/20">
            <div
                class="grid h-9 w-9 place-items-center rounded-md border border-white/40 bg-white/15 text-xs font-black text-white">
                R
            </div>
        </div>

        <nav class="flex flex-1 flex-col items-center gap-1 py-3">
            @foreach ([['Favorites', 'star'], ['Approval', 'circle-check'], ['Input', 'keyboard'], ['Request', 'clipboard-list'], ['Department Report', 'chart-no-axes-combined'], ['FB & Shop Cashier', 'shopping-bag', true], ['Sales', 'badge-dollar-sign']] as $menu)
                <button type="button" title="{{ $menu[0] }}"
                    class="flex h-[72px] w-full flex-col items-center justify-center gap-1 border-l-4 transition {{ !empty($menu[2]) ? 'border-white bg-white/15 text-white' : 'border-transparent text-blue-100 hover:bg-white/10 hover:text-white' }}">
                    <i data-lucide="{{ $menu[1] }}" class="h-4 w-4"></i>
                    <span class="origin-center -rotate-90 whitespace-nowrap text-[9px] font-semibold tracking-wide">
                        {{ $menu[0] }}
                    </span>
                </button>
            @endforeach
        </nav>
    </aside>

    <main class="ml-[58px] min-h-screen">
        {{-- Top system bar --}}
        <header
            class="flex h-[68px] items-center justify-between border-b border-slate-300 bg-[#0a1a2a] px-5 text-white shadow-md">
            <div class="flex items-center gap-3">
                <div class="grid h-9 w-9 place-items-center rounded-md bg-[#1b70b8] text-sm font-black shadow">
                    R
                </div>
                <div>
                    <p class="text-xs font-semibold tracking-wide">Ibis Makassar City Center</p>
                    <p class="text-[10px] text-slate-400">Restaurant &amp; Cashier System</p>
                </div>
            </div>

            <div class="flex items-center gap-3 text-slate-300">
                <button class="transition hover:text-white" title="Search"><i data-lucide="search"
                        class="h-4 w-4"></i></button>
                <button class="transition hover:text-white" title="Notification"><i data-lucide="bell"
                        class="h-4 w-4"></i></button>
                <button class="transition hover:text-red-300" title="Close"><i data-lucide="x"
                        class="h-4 w-4"></i></button>
            </div>
        </header>

        {{-- Breadcumb/Tabs --}}
        <div class="border-b border-slate-300 bg-[#eaf1f3] px-4 py-2">
            <div class="flex flex-wrap items-center gap-1 text-[10px] font-medium">
                <a href="#"
                    class="rounded-t border border-slate-300 bg-white px-3 py-1.5 text-slate-600 shadow-sm">
                    Open Cashier
                </a>
                <span class="text-slate-400">›</span>
                <a href="#"
                    class="rounded-t border border-slate-300 bg-white px-3 py-1.5 text-slate-600 shadow-sm">
                    Restaurant Transaction
                </a>
                <span class="text-slate-400">›</span>
                <span
                    class="rounded-t border border-b-white border-slate-300 bg-white px-3 py-1.5 font-bold text-[#1871ad] shadow-sm">
                    TABLE 01
                </span>
            </div>
        </div>

        <section class="p-3 lg:p-4">
            <div
                class="min-h-[calc(100vh-120px)] overflow-hidden rounded-sm border border-slate-300 bg-[#f9fcfd] shadow-panel">
                {{-- Action toolbar --}}
                <div class="flex flex-wrap items-center gap-1.5 border-b border-slate-200 bg-[#eff5f6] px-3 py-2">
                    <button type="button" id="addOrderButton" class="toolbar-button">
                        <i data-lucide="plus" class="h-3.5 w-3.5"></i> Add
                    </button>
                    <button type="button" class="toolbar-button">
                        <i data-lucide="pencil" class="h-3.5 w-3.5"></i> Edit
                    </button>
                    <button type="button" id="clearOrderButton" class="toolbar-button">
                        <i data-lucide="trash-2" class="h-3.5 w-3.5"></i> Delete
                    </button>
                    <button type="button" class="toolbar-button">
                        <i data-lucide="rotate-cw" class="h-3.5 w-3.5"></i> Refresh
                    </button>
                    <a href="{{ url('/table-list') }}" class="toolbar-button">
                        <i data-lucide="table-properties" class="h-3.5 w-3.5"></i> Table List
                    </a>
                    <button type="button" class="toolbar-button">
                        <i data-lucide="log-in" class="h-3.5 w-3.5"></i> Check In
                    </button>
                    <button type="button" class="toolbar-button">
                        <i data-lucide="log-out" class="h-3.5 w-3.5"></i> Check Out
                    </button>
                    <button type="button" class="toolbar-button">
                        <i data-lucide="receipt-text" class="h-3.5 w-3.5"></i> Bill
                    </button>
                    <button type="button" id="openWaiterButton" class="toolbar-button">
                        <i data-lucide="user-round" class="h-3.5 w-3.5"></i> Waiter
                    </button>

                    <span class="mx-1 hidden h-6 border-l border-slate-300 sm:block"></span>

                    <button type="button" id="saveOrderButton"
                        class="toolbar-button !border-emerald-300 !bg-emerald-50 !text-emerald-700 hover:!bg-emerald-100">
                        <i data-lucide="save" class="h-3.5 w-3.5"></i> Save
                    </button>
                    <button type="button" id="cancelOrderButton"
                        class="toolbar-button !border-rose-300 !bg-rose-50 !text-rose-700 hover:!bg-rose-100">
                        <i data-lucide="x" class="h-3.5 w-3.5"></i> Cancel
                    </button>

                    <div class="ml-auto hidden items-center gap-2 text-[10px] text-slate-500 xl:flex">
                        <span class="font-semibold text-slate-700">Ibis Kitchen</span>
                        <span class="rounded border border-slate-300 bg-white px-2 py-1">ADHA · 15 Juni 2026</span>
                    </div>
                </div>

                <div
                    class="grid min-h-[calc(100vh-182px)] grid-cols-1 xl:grid-cols-[64px_minmax(420px,1.16fr)_160px_minmax(350px,.96fr)]">
                    {{-- Kolom zone/table --}}
                    <aside class="border-b border-slate-200 bg-[#eef5f6] p-2 xl:border-b-0 xl:border-r">
                        <p class="mb-2 px-1 text-center text-[9px] font-bold uppercase tracking-wide text-slate-500">
                            Table
                        </p>

                        <div class="grid grid-cols-2 gap-1 xl:grid-cols-1">
                            @foreach ($zones as $index => $zone)
                                <button type="button" data-zone="{{ $zone }}"
                                    class="zone-button flex h-9 items-center justify-center rounded-sm border border-[#b7cbd2] bg-[#e3eff2] text-xs font-bold text-[#557984] shadow-control transition hover:border-[#6eafc8] hover:bg-[#d5ebf2] hover:text-[#226884] {{ $index === 0 ? 'ring-2 ring-[#2c88b4] ring-offset-1' : '' }}">
                                    {{ $zone }}
                                </button>
                            @endforeach
                        </div>

                        <button type="button"
                            class="mt-2 w-full rounded-sm border border-slate-300 bg-white px-1 py-2 text-[9px] font-bold text-slate-600 shadow-control hover:bg-slate-50">
                            Move<br>Split
                        </button>
                        <button type="button"
                            class="mt-1 w-full rounded-sm border border-slate-300 bg-white px-1 py-2 text-[9px] font-bold text-slate-600 shadow-control hover:bg-slate-50">
                            Row List
                        </button>
                    </aside>

                    {{-- Detail pesanan --}}
                    <section class="border-b border-slate-200 bg-[#fbfdfe] p-3 xl:border-b-0 xl:border-r">
                        <div class="grid gap-2 sm:grid-cols-[64px_1fr]">
                            <label class="field-label">Order Info</label>

                            <div class="grid gap-2 sm:grid-cols-2">
                                <div>
                                    <label class="field-label">Discount Type</label>
                                    <select class="field-control">
                                        <option>Full Payment</option>
                                        <option>Percentage</option>
                                        <option>Nominal</option>
                                    </select>
                                </div>
                                <div>
                                    <label class="field-label">Doc. No</label>
                                    <input class="field-control" value="01" readonly>
                                </div>

                                <div>
                                    <label class="field-label">PAX</label>
                                    <input id="paxInput" type="number" min="1" value="1"
                                        class="field-control">
                                </div>
                                <div>
                                    <label class="field-label">Waiter</label>
                                    <input id="waiterInput" class="field-control" value="ADHA">
                                </div>

                                <div class="sm:col-span-2">
                                    <label class="field-label">Guest Name</label>
                                    <input id="guestNameInput" class="field-control"
                                        placeholder="Masukkan nama tamu">
                                </div>
                            </div>
                        </div>

                        <div
                            class="mt-3 grid grid-cols-2 gap-1 rounded-sm border border-slate-200 bg-[#f1f6f7] p-1 text-[9px] font-bold text-slate-500 sm:grid-cols-5">
                            @foreach (['ROOM', 'GRP MASTER', 'PERMANENT FOLIO', 'GOLF PERSONAL', 'BANQUET'] as $tab)
                                <button type="button"
                                    class="order-tab rounded-sm px-1 py-2 transition hover:bg-white hover:text-[#256f94] {{ $loop->first ? 'bg-white text-[#256f94] shadow-sm' : '' }}">
                                    {{ $tab }}
                                </button>
                            @endforeach
                        </div>

                        <div class="mt-3 grid gap-2 sm:grid-cols-2">
                            <div>
                                <label class="field-label">Room</label>
                                <div class="flex gap-1">
                                    <input class="field-control" placeholder="No. Room">
                                    <button type="button" class="mini-button"><i data-lucide="search"
                                            class="h-3 w-3"></i></button>
                                </div>
                            </div>
                            <div>
                                <label class="field-label">Name</label>
                                <input class="field-control" placeholder="Nama tamu">
                            </div>
                            <div>
                                <label class="field-label">Time Zone</label>
                                <select class="field-control">
                                    <option>Breakfast</option>
                                    <option>Lunch</option>
                                    <option>Dinner</option>
                                </select>
                            </div>
                            <div>
                                <label class="field-label">Group of Chg</label>
                                <select class="field-control">
                                    <option>F&B</option>
                                    <option>Room Charge</option>
                                    <option>Cash</option>
                                </select>
                            </div>
                        </div>

                        {{-- Item list --}}
                        <div class="mt-3 overflow-hidden rounded-sm border border-slate-300 bg-white">
                            <div
                                class="flex items-center justify-between border-b border-slate-200 bg-[#edf4f6] px-3 py-2">
                                <h2 class="text-[11px] font-bold text-slate-600">Item List</h2>
                                <span id="itemCountBadge"
                                    class="rounded-full bg-sky-100 px-2 py-0.5 text-[9px] font-bold text-sky-700">0
                                    item</span>
                            </div>

                            <div class="max-h-[250px] overflow-y-auto">
                                <table class="w-full text-left text-[10px]">
                                    <thead class="sticky top-0 bg-[#f7fafb] text-slate-500">
                                        <tr class="border-b border-slate-200">
                                            <th class="px-3 py-2 font-bold">Service</th>
                                            <th class="w-14 px-2 py-2 text-center font-bold">Qty</th>
                                            <th class="w-24 px-2 py-2 text-right font-bold">Net</th>
                                            <th class="w-8 px-1 py-2"></th>
                                        </tr>
                                    </thead>
                                    <tbody id="orderItemsBody">
                                        <tr id="emptyItemRow">
                                            <td colspan="4" class="px-3 py-10 text-center text-slate-400">
                                                Belum ada item. Pilih menu di sebelah kanan.
                                            </td>
                                        </tr>
                                    </tbody>
                                </table>
                            </div>
                        </div>

                        {{-- Total --}}
                        <div class="mt-3 rounded-sm border border-slate-300 bg-[#edf4f6] p-3">
                            <div class="flex items-center justify-between border-b border-slate-300 pb-2">
                                <span class="text-sm font-black tracking-wide text-slate-600">TOTAL</span>
                                <span id="grandTotal" class="text-lg font-black text-[#1d6687]">Rp0</span>
                            </div>

                            <div class="mt-3 grid grid-cols-2 gap-1.5 sm:grid-cols-5">
                                <button class="mini-action">Delete Item</button>
                                <button class="mini-action">Chg Qty</button>
                                <button class="mini-action">+</button>
                                <button class="mini-action">-</button>
                                <button class="mini-action">Update Set</button>
                                <button class="mini-action">View Detail</button>
                                <button class="mini-action">Spec. Request</button>
                                <button class="mini-action">Move to Table</button>
                                <button class="mini-action">Print Bill</button>
                                <button class="mini-action">Pay Card</button>
                            </div>

                            <div class="mt-2 grid grid-cols-2 gap-1.5 sm:grid-cols-6">
                                <button class="mini-action">Print Kitchen</button>
                                <button class="mini-action">Reprint Kitchen</button>
                                <button class="mini-action">Print Draft</button>
                                <button class="mini-action">Event Print</button>
                                <button class="mini-action">C/B Bill</button>
                                <button class="mini-action">Settle</button>
                            </div>
                        </div>
                    </section>

                    {{-- Kategori menu --}}
                    <aside class="border-b border-slate-200 bg-[#eef5f6] p-3 xl:border-b-0 xl:border-r">
                        <label class="field-label">Search Service</label>
                        <div class="relative">
                            <input id="serviceSearch" type="search" class="field-control pr-8"
                                placeholder="Cari service">
                            <i data-lucide="search"
                                class="pointer-events-none absolute right-2 top-1/2 h-3.5 w-3.5 -translate-y-1/2 text-slate-400"></i>
                        </div>

                        <div class="mt-3 space-y-2">
                            @foreach ($serviceCategories as $index => $category)
                                <button type="button" data-category="{{ $category }}"
                                    class="category-button flex min-h-12 w-full items-center justify-center rounded-sm border border-[#a9c3cb] bg-[#e3f0f3] px-2 text-center text-[10px] font-bold leading-tight text-[#467383] shadow-control transition hover:border-[#62a7c2] hover:bg-[#d3ebf2] hover:text-[#216987] {{ $index === 0 ? 'ring-2 ring-[#3a98c4] ring-offset-1' : '' }}">
                                    {{ $category }}
                                </button>
                            @endforeach
                        </div>
                    </aside>

                    {{-- Area pilihan service --}}
                    <section class="bg-[#f9fcfd] p-3">
                        <div class="flex flex-wrap items-center justify-between gap-2 border-b border-slate-200 pb-2">
                            <div>
                                <p class="text-[10px] font-semibold text-slate-500">Service</p>
                                <h2 id="selectedCategoryTitle" class="text-sm font-bold text-slate-700">Appetizer</h2>
                            </div>
                            <button type="button" id="clearSearchButton"
                                class="text-[10px] font-semibold text-sky-700 hover:underline">
                                Reset Filter
                            </button>
                        </div>

                        <div id="serviceGrid" class="mt-3 grid grid-cols-2 gap-2 sm:grid-cols-3">
                            @foreach ($serviceItems as $item)
                                <button type="button" data-service-name="{{ $item['name'] }}"
                                    data-service-price="{{ $item['price'] }}"
                                    data-service-category="{{ $item['category'] }}"
                                    class="service-card min-h-[90px] rounded-sm border border-[#bfd0d5] bg-[#eaf3f5] p-3 text-left shadow-control transition hover:-translate-y-0.5 hover:border-[#65a9c2] hover:bg-[#d7ecf2] focus:outline-none focus:ring-4 focus:ring-sky-100">
                                    <span
                                        class="block text-[10px] font-bold leading-snug text-[#3f6c7e]">{{ $item['name'] }}</span>
                                    <span class="mt-3 block text-[10px] font-semibold text-[#267093]">
                                        Rp{{ number_format($item['price'], 0, ',', '.') }}
                                    </span>
                                </button>
                            @endforeach
                        </div>

                        <p id="noServiceMessage" class="hidden py-12 text-center text-sm text-slate-400">
                            Service tidak ditemukan pada kategori ini.
                        </p>
                    </section>
                </div>
            </div>
        </section>
    </main>
</div>

{{-- Modal pilihan waiter --}}
<dialog id="waiterModal"
    class="m-auto w-[calc(100%-2rem)] max-w-sm rounded-md border border-slate-300 bg-white p-0 shadow-2xl backdrop:bg-slate-950/40">
    <div class="border-b border-slate-200 bg-[#edf4f6] px-4 py-3">
        <h2 class="text-sm font-bold text-slate-700">Pilih Waiter</h2>
    </div>
    <div class="space-y-2 p-4">
        @foreach (['ADHA', 'FARHAN', 'NURUL', 'RIZKY'] as $waiter)
            <button type="button" data-waiter="{{ $waiter }}"
                class="waiter-choice w-full rounded-sm border border-slate-200 px-3 py-2 text-left text-sm font-medium text-slate-600 transition hover:border-sky-300 hover:bg-sky-50 hover:text-sky-700">
                {{ $waiter }}
            </button>
        @endforeach
    </div>
    <div class="flex justify-end border-t border-slate-200 bg-slate-50 px-4 py-3">
        <button type="button" id="closeWaiterButton"
            class="rounded-sm border border-slate-300 bg-white px-4 py-2 text-xs font-bold text-slate-600 hover:bg-slate-100">
            Cancel
        </button>
    </div>
</dialog>

@push('style')
    <style>
        .toolbar-button {
            display: inline-flex;
            min-height: 30px;
            align-items: center;
            gap: .35rem;
            border-radius: 2px;
            border: 1px solid #bdccd1;
            background: #fff;
            padding: .35rem .55rem;
            font-size: 10px;
            font-weight: 700;
            color: #526c75;
            box-shadow: inset 0 1px 0 rgba(255, 255, 255, .9), 0 1px 1px rgba(15, 23, 42, .06);
            transition: .15s ease;
        }

        .toolbar-button:hover {
            background: #e8f4f7;
            border-color: #77abc0;
            color: #1f6586;
        }

        .field-label {
            display: block;
            margin-bottom: .25rem;
            font-size: 9px;
            font-weight: 700;
            text-transform: uppercase;
            letter-spacing: .035em;
            color: #6b7f86;
        }

        .field-control {
            height: 30px;
            width: 100%;
            border-radius: 2px;
            border: 1px solid #c3d0d4;
            background: #fff;
            padding: .35rem .5rem;
            font-size: 11px;
            color: #435d66;
            outline: none;
            box-shadow: inset 0 1px 1px rgba(15, 23, 42, .04);
        }

        .field-control:focus {
            border-color: #53a3c6;
            box-shadow: 0 0 0 3px rgba(56, 189, 248, .16);
        }

        .mini-button {
            display: grid;
            height: 30px;
            width: 32px;
            place-items: center;
            border-radius: 2px;
            border: 1px solid #c3d0d4;
            background: #fff;
            color: #607b84;
        }

        .mini-button:hover {
            background: #e8f4f7;
            color: #226a8b;
        }

        .mini-action {
            min-height: 29px;
            border-radius: 2px;
            border: 1px solid #c4d1d5;
            background: #fff;
            padding: .35rem .3rem;
            font-size: 9px;
            font-weight: 700;
            color: #627980;
            box-shadow: inset 0 1px 0 rgba(255, 255, 255, .9);
            transition: .15s ease;
        }

        .mini-action:hover {
            border-color: #7bb4c8;
            background: #e5f3f7;
            color: #246a8a;
        }
    </style>
@endpush

@push('scripts')
    <script>
        lucide.createIcons({
            attrs: {
                'stroke-width': 1.8
            }
        });

        const orderItems = [];
        const orderItemsBody = document.getElementById('orderItemsBody');
        const emptyItemRow = document.getElementById('emptyItemRow');
        const grandTotal = document.getElementById('grandTotal');
        const itemCountBadge = document.getElementById('itemCountBadge');
        const serviceSearch = document.getElementById('serviceSearch');
        const serviceCards = [...document.querySelectorAll('.service-card')];
        const categoryButtons = [...document.querySelectorAll('.category-button')];
        const selectedCategoryTitle = document.getElementById('selectedCategoryTitle');
        const noServiceMessage = document.getElementById('noServiceMessage');
        const zoneButtons = [...document.querySelectorAll('.zone-button')];
        const orderTabs = [...document.querySelectorAll('.order-tab')];
        const waiterModal = document.getElementById('waiterModal');
        const waiterInput = document.getElementById('waiterInput');

        let activeCategory = 'Appetizer';

        function formatRupiah(number) {
            return new Intl.NumberFormat('id-ID', {
                style: 'currency',
                currency: 'IDR',
                maximumFractionDigits: 0
            }).format(number);
        }

        function renderOrder() {
            const totalQty = orderItems.reduce((sum, item) => sum + item.qty, 0);
            const total = orderItems.reduce((sum, item) => sum + (item.price * item.qty), 0);

            itemCountBadge.textContent = `${totalQty} item`;
            grandTotal.textContent = formatRupiah(total);

            if (orderItems.length === 0) {
                orderItemsBody.innerHTML = `
                <tr id="emptyItemRow">
                    <td colspan="4" class="px-3 py-10 text-center text-slate-400">
                        Belum ada item. Pilih menu di sebelah kanan.
                    </td>
                </tr>
            `;
                return;
            }

            orderItemsBody.innerHTML = orderItems.map((item, index) => `
            <tr class="border-b border-slate-100 hover:bg-slate-50">
                <td class="px-3 py-2 font-semibold text-slate-600">${item.name}</td>
                <td class="px-2 py-2 text-center">
                    <div class="inline-flex items-center overflow-hidden rounded-sm border border-slate-200 bg-white">
                        <button class="qty-button px-1.5 py-1 text-slate-500 hover:bg-slate-100" data-index="${index}" data-change="-1">−</button>
                        <span class="min-w-6 px-1 text-center text-slate-700">${item.qty}</span>
                        <button class="qty-button px-1.5 py-1 text-slate-500 hover:bg-slate-100" data-index="${index}" data-change="1">+</button>
                    </div>
                </td>
                <td class="px-2 py-2 text-right font-semibold text-[#2a6d8c]">${formatRupiah(item.price * item.qty)}</td>
                <td class="px-1 py-2 text-center">
                    <button class="remove-item rounded p-1 text-slate-400 hover:bg-rose-50 hover:text-rose-600" data-index="${index}" title="Hapus item">
                        <i data-lucide="x" class="h-3.5 w-3.5"></i>
                    </button>
                </td>
            </tr>
        `).join('');

            lucide.createIcons({
                attrs: {
                    'stroke-width': 1.8
                }
            });

            document.querySelectorAll('.qty-button').forEach((button) => {
                button.addEventListener('click', () => {
                    const index = Number(button.dataset.index);
                    const change = Number(button.dataset.change);

                    orderItems[index].qty += change;
                    if (orderItems[index].qty <= 0) {
                        orderItems.splice(index, 1);
                    }
                    renderOrder();
                });
            });

            document.querySelectorAll('.remove-item').forEach((button) => {
                button.addEventListener('click', () => {
                    orderItems.splice(Number(button.dataset.index), 1);
                    renderOrder();
                });
            });
        }

        function addService(name, price) {
            const existingItem = orderItems.find((item) => item.name === name);
            if (existingItem) {
                existingItem.qty += 1;
            } else {
                orderItems.push({
                    name,
                    price: Number(price),
                    qty: 1
                });
            }
            renderOrder();
        }

        function filterServices() {
            const keyword = serviceSearch.value.trim().toLowerCase();
            let visibleCount = 0;

            serviceCards.forEach((card) => {
                const category = card.dataset.serviceCategory;
                const name = card.dataset.serviceName.toLowerCase();

                const matchesCategory = category === activeCategory;
                const matchesKeyword = !keyword || name.includes(keyword);
                const visible = matchesCategory && matchesKeyword;

                card.classList.toggle('hidden', !visible);
                if (visible) visibleCount++;
            });

            noServiceMessage.classList.toggle('hidden', visibleCount > 0);
        }

        serviceCards.forEach((card) => {
            card.addEventListener('click', () => {
                addService(card.dataset.serviceName, card.dataset.servicePrice);
            });
        });

        categoryButtons.forEach((button) => {
            button.addEventListener('click', () => {
                activeCategory = button.dataset.category;
                selectedCategoryTitle.textContent = activeCategory;

                categoryButtons.forEach((item) => {
                    item.classList.remove('ring-2', 'ring-[#3a98c4]', 'ring-offset-1');
                });

                button.classList.add('ring-2', 'ring-[#3a98c4]', 'ring-offset-1');
                filterServices();
            });
        });

        serviceSearch.addEventListener('input', filterServices);

        document.getElementById('clearSearchButton').addEventListener('click', () => {
            activeCategory = 'Appetizer';
            serviceSearch.value = '';
            selectedCategoryTitle.textContent = activeCategory;

            categoryButtons.forEach((button) => {
                button.classList.toggle(
                    'ring-2',
                    button.dataset.category === activeCategory
                );
                button.classList.toggle(
                    'ring-[#3a98c4]',
                    button.dataset.category === activeCategory
                );
                button.classList.toggle(
                    'ring-offset-1',
                    button.dataset.category === activeCategory
                );
            });

            filterServices();
        });

        zoneButtons.forEach((button) => {
            button.addEventListener('click', () => {
                zoneButtons.forEach((item) => {
                    item.classList.remove('ring-2', 'ring-[#2c88b4]', 'ring-offset-1');
                });
                button.classList.add('ring-2', 'ring-[#2c88b4]', 'ring-offset-1');

                document.querySelector('.rounded-t.border-b-white')?.replaceChildren(
                    `TABLE ${button.dataset.zone}01`);
            });
        });

        orderTabs.forEach((tab) => {
            tab.addEventListener('click', () => {
                orderTabs.forEach((item) => {
                    item.classList.remove('bg-white', 'text-[#256f94]', 'shadow-sm');
                });
                tab.classList.add('bg-white', 'text-[#256f94]', 'shadow-sm');
            });
        });

        document.getElementById('clearOrderButton').addEventListener('click', () => {
            if (orderItems.length === 0 || confirm('Hapus semua item pesanan?')) {
                orderItems.splice(0, orderItems.length);
                renderOrder();
            }
        });

        document.getElementById('cancelOrderButton').addEventListener('click', () => {
            if (confirm('Batalkan transaksi ini?')) {
                orderItems.splice(0, orderItems.length);
                document.getElementById('guestNameInput').value = '';
                document.getElementById('paxInput').value = 1;
                renderOrder();
            }
        });

        document.getElementById('saveOrderButton').addEventListener('click', () => {
            const total = orderItems.reduce((sum, item) => sum + (item.price * item.qty), 0);
            if (orderItems.length === 0) {
                alert('Silakan tambahkan service terlebih dahulu.');
                return;
            }

            alert(`Pesanan disimpan.\nTotal: ${formatRupiah(total)}`);
        });

        document.getElementById('addOrderButton').addEventListener('click', () => {
            serviceSearch.focus();
        });

        document.getElementById('openWaiterButton').addEventListener('click', () => waiterModal.showModal());
        document.getElementById('closeWaiterButton').addEventListener('click', () => waiterModal.close());

        document.querySelectorAll('.waiter-choice').forEach((button) => {
            button.addEventListener('click', () => {
                waiterInput.value = button.dataset.waiter;
                waiterModal.close();
            });
        });

        waiterModal.addEventListener('click', (event) => {
            if (event.target === waiterModal) waiterModal.close();
        });

        filterServices();
        renderOrder();
    </script>
@endpush
