<x-layouts.app>
    @component('daily-cashier-section.daily-cashier-summary-print')

    @endcomponent
</x-layouts.app>
